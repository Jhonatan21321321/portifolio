# Configurações compartilhadas
# python -m streamlit run C:\Users\JhonatanAguiarCruz\Downloads\REAL-TIME-main\dashboard\APP.py

import os

# Credenciais (em produção, use variáveis de ambiente ou secrets)
AUTH = ('jhonatan.cruz@superbet.com/token', 'R6kLtMHNepew780Sp6xIKAkksixfOkXGpWQwbdKb')
BASE_URL = 'https://superbetbr.zendesk.com/api/v2'


