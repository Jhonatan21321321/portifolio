import pandas as pd
from datetime import timedelta
import re
from .zendesk_connector import fetch_tickets, fetch_user_data, fetch_user_groups

# Regex para bater exatamente com as tags de sentimento
SENTIMENT_PATTERN = re.compile(
    r'^sentiment__(very_positive|positive|neutral|negative|very_negative)$',
    re.IGNORECASE
)

def extract_sentiment_from_tags(tags):
    """
    Retorna 'very positive' | 'positive' | 'neutral' | 'negative' | 'very negative'
    ou None se não houver tag 'sentiment__...'.
    """
    if not isinstance(tags, list):
        return None
    for t in tags:
        if not isinstance(t, str):
            continue
        m = SENTIMENT_PATTERN.match(t.strip().lower())
        if m:
            return m.group(1).replace('_', ' ')
    return None

def process_zendesk_data(minutes_back=5):
    try:
        tickets = fetch_tickets(minutes_back)
        if not tickets:
            print("Nenhum ticket retornado pela API")
            return pd.DataFrame()
        df = pd.DataFrame(tickets)
    except Exception as e:
        print(f"Erro no processamento de dados: {e}")
        return pd.DataFrame()
    
    # via_channel
    if 'via' in df.columns:
        df['via_channel'] = df['via'].str.get('channel')

    # sentiment_5 somente a partir das tags
    if 'tags' in df.columns:
        df['sentiment_5'] = df['tags'].apply(extract_sentiment_from_tags)
        df['tags'] = df['tags'].apply(lambda x: ', '.join(x) if isinstance(x, list) else None)
    else:
        df['sentiment_5'] = None

    # satisfaction_rating numérico
    if 'satisfaction_rating' in df.columns:
        df['satisfaction_rating'] = pd.to_numeric(df['satisfaction_rating'], errors='coerce')

    # Inicializar colunas
    df['assignee_name'] = None
    df['assignee_groups'] = None
    df['assignee_last_login_at'] = None

    # Dados de usuários
    if 'assignee_id' in df.columns:
        try:
            # Converter assignee_id para int64 (suporta números grandes)
            df['assignee_id'] = pd.to_numeric(df['assignee_id'], errors='coerce').astype('Int64')
            
            # Pegar IDs únicos válidos
            user_ids = df['assignee_id'].dropna().unique().tolist()
            
            if user_ids:
                users = fetch_user_data(user_ids)
                
                if users:
                    # Criar dicionários de mapeamento
                    id_to_name = {u['id']: u.get('name') for u in users}
                    id_to_groups = {}
                    id_to_last_login = {}
                    
                    for user_id in user_ids:
                        groups = fetch_user_groups(user_id)
                        id_to_groups[user_id] = ', '.join([g.get('name', '') for g in groups if g.get('name')])
                        user = next((u for u in users if u['id'] == user_id), None)
                        id_to_last_login[user_id] = user.get('last_login_at') if user else None
                    
                    # Aplicar mapeamentos
                    df['assignee_name'] = df['assignee_id'].map(id_to_name)
                    df['assignee_groups'] = df['assignee_id'].map(id_to_groups)
                    df['assignee_last_login_at'] = df['assignee_id'].map(id_to_last_login)
        except Exception as e:
            print(f"Erro ao processar assignee_id: {e}")
    
    # Fuso horário
    for col in ['created_at', 'updated_at', 'assignee_last_login_at']:
        if col in df.columns:
            df[col] = (pd.to_datetime(df[col], errors='coerce') - timedelta(hours=3)).dt.strftime('%Y-%m-%d %H:%M:%S')
    
    # Seleção de colunas
    cols = [
        'id', 'assignee_name', 'status', 'via_channel',
        'type', 'created_at', 'updated_at', 'satisfaction_rating', 'sentiment_5',
        'tags', 'assignee_groups', 'assignee_last_login_at'
    ]
    existing_cols = [c for c in cols if c in df.columns]
    return df[existing_cols] if existing_cols else pd.DataFrame()